const appCard = document.getElementById("app");
const generateBtn = document.getElementById("cardGenerator");


// creating the element 

function profileCard(){
    const profile = document.createElement("div");
    profile.className = "profile-card";
    
    // creating the image

    const profileImg = document.createElement("img");
    profileImg.className = "imageCss";
    profileImg.src = "mine.jpg";

    // creating the element for Name 

    const profileName = document.createElement("h3");
    profileName.textContent="ChandraShekar";

    // Creating the element for decription

    const profileDes = document.createElement("p");
    profileDes.textContent = "Passionate Web Developer | Learning JavaScript & React";
    
    // Appending the child

    profile.appendChild(profileImg);
    profile.appendChild(profileName);
    profile.appendChild(profileDes);
    appCard.appendChild(profile);

}

// Generating the profile card when the  generate button is clicked

generateBtn.addEventListener("click",profileCard);