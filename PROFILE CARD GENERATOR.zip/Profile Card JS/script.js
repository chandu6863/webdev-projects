const appCard = document.getElementById("app");
const generateBtn = document.getElementById("cardGenerator");
// creating the element 
function profileCard(){
    const profile = document.createElement("div");
    profile.className = "profile-card";
    // creating the image
     console.log(profile);
    const profileImg = document.createElement("img");
    profileImg.className = "imageCss";
    profileImg.src = "https://media.istockphoto.com/id/1434212178/photo/middle-eastern-lady-using-laptop-working-online-sitting-in-office.jpg?s=2048x2048&w=is&k=20&c=U0nKYf9Ggh8S77U7DvPlFpRE0bKiSOD9gr9naxHEpfM=";

    const profileName = document.createElement("h3");
    profileName.textContent="ChandraShekar";

    const profileDes = document.createElement("p");
    profileDes.textContent = "I am passinate towards web development and having knowledge on JS and React";

    profile.appendChild(profileImg);
    profile.appendChild(profileName);
    profile.appendChild(profileDes);
    appCard.appendChild(profile);

}
generateBtn.addEventListener("click",profileCard);