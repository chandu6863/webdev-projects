document.getElementById("btn").addEventListener("click",function(){
let randomNum=Math.floor(Math.random()*(50-1)+1);
// console.log(randomNum);
let inputNum = parseInt(document.getElementById("number").value);
let result = document.getElementById("result");

if(randomNum==inputNum)
{
    result.innerHTML="You have guessed the correct number";
}
else{
    result.innerHTML="You have not guessed the correct number";
}
});
